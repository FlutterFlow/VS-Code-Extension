package com.mycompany.vscodetest

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
